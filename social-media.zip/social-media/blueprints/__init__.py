from .user import bp as user_bp
from .q_a import bp as qa_bp
from .mine import bp as mine_bp
from .collect import bp as collect_bp
from .admin import bp as admin_bp